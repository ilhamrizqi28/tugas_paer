<?php
 define('HOST','localhost');
 define('USER','id12170456_lham123');
 define('PASS','Oke1234ilham#');
 define('DB','id12170456_ilham_rizqi');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 